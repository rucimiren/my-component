const { resolve } = require('path')

module.exports = (options, context) => ({
  define () {
    const { clean, messages, theme, modelStyle, btnStyle, width, height, messageStyle, backStyle } = options
    return {
      CLEAN: clean || false,
      THEME: theme || ['blackCat', 'whiteCat', 'haru1', 'haru2', 'haruto', 'koharu', 'izumi', 'shizuku', 'wanko', 'miku', 'z16'],
      MESSAGES: messages || {
        welcome: '',
        home: 'You are the Apple of my eye and I want to bring you home',
        theme: 'OK, I hope you love my other friends',
        close: 'I love you most',
        info: 'Do you want to know more about me?'
      },
      MESSAGE_STYLE: messageStyle || {
        right: '68px',
        bottom: '190px'
      },
      MODEL_STYLE: modelStyle || {
        right: '90px',
        bottom: '-20px',
        opacity: '0.9'
      },
      BTN_STYLE: btnStyle || {
        right: '90px',
        bottom: '40px'
      },
      WIDTH: width || 150,
      HEIGHT: height || 220,
      BACK_STYLE: backStyle
    }
  },
  name: 'vuepress-plugin-cat-model',
  enhanceAppFiles: resolve(__dirname, './bin/enhanceAppFile.js'),
  globalUIComponents: 'CatModel'
})
